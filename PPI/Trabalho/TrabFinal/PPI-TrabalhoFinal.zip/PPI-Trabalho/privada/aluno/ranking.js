$(document).ready(function() {
  $('#rankingTable').DataTable();
});