const curso1Like = document.getElementById("curso1-like");
const curso2Like = document.getElementById("curso2-like");
const curso3Like = document.getElementById("curso3-like");
const curso4Like = document.getElementById("curso4-like");
const curso5Like = document.getElementById("curso5-like");

curso1Like.addEventListener("click", function () {
    if (curso1Like.classList.contains("far")) {
        curso1Like.classList.remove("far");
        curso1Like.classList.add("fas");
    } else {
        curso1Like.classList.remove("fas");
        curso1Like.classList.add("far");
    }
});

curso2Like.addEventListener("click", function () {
    if (curso1Like.classList.contains("far")) {
        curso1Like.classList.remove("far");
        curso1Like.classList.add("fas");
    } else {
        curso1Like.classList.remove("fas");
        curso1Like.classList.add("far");
    }
});

curso3Like.addEventListener("click", function () {
    if (curso1Like.classList.contains("far")) {
        curso1Like.classList.remove("far");
        curso1Like.classList.add("fas");
    } else {
        curso1Like.classList.remove("fas");
        curso1Like.classList.add("far");
    }
});

curso4Like.addEventListener("click", function () {
    if (curso1Like.classList.contains("far")) {
        curso1Like.classList.remove("far");
        curso1Like.classList.add("fas");
    } else {
        curso1Like.classList.remove("fas");
        curso1Like.classList.add("far");
    }
});

curso5Like.addEventListener("click", function () {
    if (curso1Like.classList.contains("far")) {
        curso1Like.classList.remove("far");
        curso1Like.classList.add("fas");
    } else {
        curso1Like.classList.remove("fas");
        curso1Like.classList.add("far");
    }
});